def generate_cipher_key():
    key = {'a': 'c', 'b': 'd', 'c': 'e', 'd': 'f', 'e': 'g',
           'f': 'h', 'g': 'i', 'h': 'j', 'i': 'k', 'j': 'l',
           'k': 'm', 'l': 'n', 'm': 'o', 'n': 'p', 'o': 'q',
           'p': 'r', 'q': 's', 'r': 't', 's': 'u', 't': 'v',
           'u': 'w', 'v': 'x', 'w': 'y', 'x': 'z', 'y': 'a',
           'z': 'b'}

    return key

def encrypt_message(message, key):
    encrypted_message = ""
    for char in message:
        if char.lower() in key:
            encrypted_message += key[char.lower()]
        else:
            encrypted_message += char

    return encrypted_message

def decrypt_message(encrypted_message, key):
    decrypted_message = ""
    for char in encrypted_message:
        if char.lower() in key.values():
            for k, v in key.items():
                if char.lower() == v:
                    if char.isupper():
                        decrypted_message += k.upper()
                    else:
                        decrypted_message += k
        else:
            decrypted_message += char

    return decrypted_message

key = generate_cipher_key()
plaintext = "Hello"
encrypted = encrypt_message(plaintext, key)
decrypted = decrypt_message(encrypted, key)

print("Alice:", plaintext)
print("Bob:", encrypted)
print("Eve:", decrypted)